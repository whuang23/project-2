The gfx/ folder is where you store all of the images and artwork files called by CSS (as opposed to
images called by the XHTML <img /> tag, which belong in the media/img/ folder).
