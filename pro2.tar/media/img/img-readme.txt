The img/ folder should contain all of the image files for a project (.jpg, .png) that are called by
the HTML <img /> tag. (Images referred to in the CSS can be stored in the css/gfx/ sub-folder.)
