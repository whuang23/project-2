The media folder should contain all of the meda files--audio, images, PDFs, Flash movies, video--for
a site or project. Each media type has its own sub-folder to help keep things organized.
